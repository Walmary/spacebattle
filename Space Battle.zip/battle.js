
// Our Ship
let USSAssembly = {

    dodge: function(){
        // allows us to retreat
    }
}
// -------------------------------------------------



const battle = () =>{
    // attack()
        // if(alien.life = 0){then they attack}


    // PlayerOne


    // PlayerTwo
}





let alienMob = []


// ROund => each Player gets to attack

// -----------------------------------------------------


